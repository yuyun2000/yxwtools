# yxwtools

个人工具库



#### 代码说明


- resample.py 包括函数wavresample，生成对应采样率的wav文件并直接替换
- get_audio_info 获取目录下音频数据的统计信息，包含各种时长的分布
- convert_mp3_to_wav convert_flac_to_wav 讲一个目录下的mp3 flac音频转换为wav音频



#### TODO
- 多种格式音频支持
- ...